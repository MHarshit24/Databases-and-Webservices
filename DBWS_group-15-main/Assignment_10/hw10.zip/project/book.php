<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang = en> 
<head> 
<title> 
Weebook
</title> 
<meta charset = utf-8> 
<link rel="stylesheet" href="style2.css" media="all"/> 
<meta name="keywords" content="group15" /> 
<meta name="description" content="Weebook"/> 
<meta name="author" content="group15" /> 
<link href="http://fonts.cdnfonts.com/css/blackadder-itc" rel="stylesheet">
<style>
@import url('http://fonts.cdnfonts.com/css/blackadder-itc');
</style>
</head> 
<body> 
<?php
$servername = "localhost";
$username = "group15";
$password = "riskvolume";
$dbname = "group15";

// Create connection
$conn =  mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$query= "SELECT * FROM item INNER JOIN book ON item.item_id = book.book_id WHERE book.book_id = $_GET[item] ;";
$result=mysqli_query($conn,$query);
if(!$result){
  die('Error: ' . mysqli_error($conn));
}
?>
<div class="main border">
<div class="floating_right border">
<h1 class="text_center">Newest Book</h1>
<div class="div_center">
<div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 2</h1>
  <p class="price">$24.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
</div>
</div>
<div class="floating_left border">
<div class="div_center">
<h1 class="text_center">News</h1>
 <h2 align="justify">Breathless by David Quammen review – an expert eye on Covid’s past and future</h2>
  <p align="justify">The veteran science writer brings a naturalist’s eye to the complexities of viruses and the tangle of conspiracy theories in his thoroughly readable guide
  Covid-19 is the first pandemic in which molecular genomics has been applied at scale. Thanks to this science, researchers were able to publish the genome of the novel coronavirus,
  Sars-CoV-2, in record time and keep pace with the emergence of new variants.</p>
</div>
</div>
 <div  class="head border">
 <div class="pic"><a href="index.php" ><img width="100%" src="images/logo.png"></a></div>
  <div class="form border">
  <form action="/test.php" >
      <input type="text" class="search border" placeholder="Search.." name="search">
   <button type="submit" class="but border">Submit</button>
   </form>
   <div class="take_33">
   <a href="#m_ch"><button class="but_head border">Books</button></a>
   </div>
   <div class="take_33">
   <a href="#m_ch"><button class="but_head border">News</button></a>
   </div>
   <div class="take_33">
   <a href="#m_ch" ><button class="but_head border">Account</button></a>
   </div>

   </div>
     <div class="user border_golden" ><p>user</p></div>
         <div class="user border"> <p>cart</p></div>
  </div> 
  <div class="border">
  <h1 class="text_center"><a href="maintance.html" class="text_center">maintance page</a></h1>
  <h1 class="text_center"><a href="special_search.php" class="text_center">special SEARCH page</a></h1>
  </div>
  
  <div class="book border">
    <div class='book_cover border'> <?php 
    $row = mysqli_fetch_assoc($result);
     echo('<img src="images/'. $row['picture_id'] . '" alt="Book" style="width:100%">'); ?></div>
    <div class="book_info"><?php 
    echo('<h1> ' . $row['title'] . '</h1>'); 
    $category_query = "SELECT * FROM category INNER JOIN item_category ON item_category.category_id = category.category_id where item_category.item_id =  $_GET[item];"; 
    $category_result = mysqli_query($conn, $category_query);
    echo'<p>category: ';
    while($row_c = mysqli_fetch_array($category_result))
      {
        echo ($row_c['name'] . " ") ;
      } 
      echo '</p>'  ;
    echo('<h2> ' . $row['description'] . '</h2>'); 
    echo('<h2 class="price"> ' . $row['price'] . '$</h2>'); ?>   <button class="border">Add to Cart</button></div>
   
  </div>
  <div class="no_col">
  <h1 class="text_center">Popular Books</h1>
  <div class="border books">
  <div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 1</h1>
  <p class="price">$19.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
<div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 2</h1>
  <p class="price">$24.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
  <div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 3</h1>
  <p class="price">$9.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
<div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 4</h1>
  <p class="price">$49.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
</div>
</div>

<div>
   <h1 class="text_center">Comedy Books</h1>
  <div class="border books">
  <div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 1</h1>
  <p class="price">$19.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
<div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 2</h1>
  <p class="price">$24.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
  <div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 3</h1>
  <p class="price">$9.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
<div class='space'></div>
<div class="card">
  <img src="images/Book.png" alt="Book" style="width:100%">
  <h1>Cool Book 4</h1>
  <p class="price">$49.99</p>
  <p>Cool book</p>
  <p><button>Add to Cart</button></p>
</div>
</div>


  </div>
</body>

