<?php
$servername = "localhost";
$username = "group15";
$password = "riskvolume";
$dbname = "group15";

// Create connection
// $conn =  mysqli_connect($servername, $username, $password,$dbname);
$mysqli = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($mysqli -> connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
    exit();
  }
echo "Connected successfully";
$query= "SELECT EXISTS(SELECT login, password from user WHERE login='$_POST[login]' AND password='$_POST[password]') as exist"; 
$result = $mysqli -> query($query);
$row = mysqli_fetch_assoc($result);
if ($row["exist"] == 1){
  echo "Login succesfull";
  header("Location: http://clabsql.clamv.jacobs-university.de/~tpashakulo/maintance.html");
  exit();
} else {
  echo "Either passowrd of login is wrong";
}
?>