<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html lang = en> 
<head> 
<title> 
Weebook
</title> 
<meta charset = utf-8> 
<link rel="stylesheet" href="style2.css" media="all"/> 
<meta name="keywords" content="group15" /> 
<meta name="description" content="Weebook"/> 
<meta name="author" content="group15" /> 
<link href="http://fonts.cdnfonts.com/css/blackadder-itc" rel="stylesheet">
<style>
@import url('http://fonts.cdnfonts.com/css/blackadder-itc');
</style>
</head> 
<body> 
<?php
        $servername = "localhost";
        $username = "group15";
        $password = "riskvolume";
        $dbname = "group15";
        
        // Create connection
        $conn =  mysqli_connect($servername, $username, $password,$dbname);
        
        // Check connection
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        
        $news_query = "SELECT * FROM news WHERE date >= '". $_POST['date'] . "';";

        ?>
<div class="main border">
<div  class="head border">
 <div class="pic"><a href="index.php" ><img width="100%" src="images/logo.png"></a></div>
  <div class="form border">
  <form action="/test.php" >
      <input type="text" class="search border" placeholder="Search.." name="search">
   <button type="submit" class="but border">Submit</button>
   </form>
   <div class="take_33">
   <a href="#m_ch"><button class="but_head border">Books</button></a>
   </div>
   <div class="take_33">
   <a href="#m_ch"><button class="but_head border">News</button></a>
   </div>
   <div class="take_33">
   <a href="#m_ch" ><button class="but_head border">Account</button></a>
   </div>

   </div>
     <div class="user border_golden" ><p>user</p></div>
         <div class="user border"> <p>cart</p></div>
  </div> 
  <div class="border">
  <h1 class="text_center"><a href="maintance.html" class="text_center">maintance page</a></h1>
  <h1 class="text_center"><a href="special_search.php" class="text_center">special SEARCH page</a></h1>
  </div>
  <?php 
  $news_result = mysqli_query($conn, $news_query);
  echo '<h1 class = "text_center"> Search result  </h1>';
  if(mysqli_num_rows($news_result)>1)
  {
            while($row = mysqli_fetch_array($news_result))
              {
                echo "<h1 class='text_center'><a href='news.php?news=" . $row['news_id'] . "'>"  . $row['title'] . "</a></h1>";
              }   
            }
            else{
                echo "error:empry set(";
            }
              ?>  
</div>